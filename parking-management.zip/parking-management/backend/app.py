import math
import os
import sqlite3
from datetime import datetime

from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # lets the React app (port 5173) call this API (port 5000)

DB_PATH = os.path.join(os.path.dirname(__file__), "parking.db")

RATE_PER_HOUR = 20   # rupees per hour
TOTAL_SLOTS = 10     # slots A1 to A10 are created on first run
TIME_FORMAT = "%Y-%m-%d %H:%M:%S"


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # rows behave like dictionaries
    return conn


def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS slots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            slot_number TEXT NOT NULL UNIQUE,
            is_occupied INTEGER DEFAULT 0
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS parking (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            slot_id INTEGER NOT NULL,
            vehicle_number TEXT NOT NULL,
            entry_time TEXT NOT NULL,
            exit_time TEXT,
            fee INTEGER,
            FOREIGN KEY (slot_id) REFERENCES slots(id)
        )
    """)

    # Create the slots only once
    count = conn.execute("SELECT COUNT(*) FROM slots").fetchone()[0]
    if count == 0:
        for i in range(1, TOTAL_SLOTS + 1):
            conn.execute("INSERT INTO slots (slot_number) VALUES (?)", (f"A{i}",))

    conn.commit()
    conn.close()


def calculate_fee(entry_time, exit_time):
    """Fee rule: rate x hours, rounded UP to the next hour, minimum 1 hour."""
    seconds = (exit_time - entry_time).total_seconds()
    hours = max(1, math.ceil(seconds / 3600))
    return hours, hours * RATE_PER_HOUR


# All slots, with the vehicle number if the slot is occupied (LEFT JOIN)
@app.route("/api/slots", methods=["GET"])
def get_slots():
    conn = get_db()
    rows = conn.execute("""
        SELECT slots.id, slots.slot_number, slots.is_occupied, parking.vehicle_number
        FROM slots
        LEFT JOIN parking
            ON parking.slot_id = slots.id AND parking.exit_time IS NULL
        ORDER BY slots.id
    """).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


# Check-in: park a vehicle in the first free slot
@app.route("/api/checkin", methods=["POST"])
def check_in():
    data = request.get_json()
    vehicle = (data.get("vehicle_number") or "").strip().upper()

    if not vehicle:
        return jsonify({"error": "Enter a vehicle number"}), 400

    conn = get_db()

    # The same vehicle cannot be parked twice
    already = conn.execute(
        "SELECT id FROM parking WHERE vehicle_number = ? AND exit_time IS NULL",
        (vehicle,),
    ).fetchone()
    if already:
        conn.close()
        return jsonify({"error": f"{vehicle} is already parked"}), 400

    # Find the first free slot
    slot = conn.execute(
        "SELECT id, slot_number FROM slots WHERE is_occupied = 0 ORDER BY id LIMIT 1"
    ).fetchone()
    if slot is None:
        conn.close()
        return jsonify({"error": "Parking is full"}), 400

    now = datetime.now().strftime(TIME_FORMAT)
    conn.execute(
        "INSERT INTO parking (slot_id, vehicle_number, entry_time) VALUES (?, ?, ?)",
        (slot["id"], vehicle, now),
    )
    conn.execute("UPDATE slots SET is_occupied = 1 WHERE id = ?", (slot["id"],))
    conn.commit()
    conn.close()
    return jsonify({"message": f"{vehicle} parked in slot {slot['slot_number']}"}), 201


# Check-out: calculate the fee and free the slot
@app.route("/api/checkout/<int:parking_id>", methods=["PUT"])
def check_out(parking_id):
    conn = get_db()
    record = conn.execute("""
        SELECT parking.id, parking.slot_id, parking.vehicle_number,
               parking.entry_time, slots.slot_number
        FROM parking
        JOIN slots ON parking.slot_id = slots.id
        WHERE parking.id = ? AND parking.exit_time IS NULL
    """, (parking_id,)).fetchone()

    if record is None:
        conn.close()
        return jsonify({"error": "Parking record not found"}), 404

    now = datetime.now()
    entry = datetime.strptime(record["entry_time"], TIME_FORMAT)
    hours, fee = calculate_fee(entry, now)

    conn.execute(
        "UPDATE parking SET exit_time = ?, fee = ? WHERE id = ?",
        (now.strftime(TIME_FORMAT), fee, parking_id),
    )
    conn.execute("UPDATE slots SET is_occupied = 0 WHERE id = ?", (record["slot_id"],))
    conn.commit()
    conn.close()

    return jsonify({
        "message": f"{record['vehicle_number']} left slot {record['slot_number']}",
        "hours": hours,
        "fee": fee,
    })


# Vehicles that are parked right now (SQL JOIN)
@app.route("/api/parked", methods=["GET"])
def parked():
    conn = get_db()
    rows = conn.execute("""
        SELECT parking.id, parking.vehicle_number, slots.slot_number, parking.entry_time
        FROM parking
        JOIN slots ON parking.slot_id = slots.id
        WHERE parking.exit_time IS NULL
        ORDER BY parking.entry_time DESC
    """).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


# Last 10 completed visits
@app.route("/api/history", methods=["GET"])
def history():
    conn = get_db()
    rows = conn.execute("""
        SELECT parking.id, parking.vehicle_number, slots.slot_number,
               parking.entry_time, parking.exit_time, parking.fee
        FROM parking
        JOIN slots ON parking.slot_id = slots.id
        WHERE parking.exit_time IS NOT NULL
        ORDER BY parking.exit_time DESC
        LIMIT 10
    """).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


# Dashboard numbers: free slots, occupied slots, today's earnings (SQL aggregates)
@app.route("/api/summary", methods=["GET"])
def summary():
    conn = get_db()
    total = conn.execute("SELECT COUNT(*) FROM slots").fetchone()[0]
    occupied = conn.execute(
        "SELECT COUNT(*) FROM slots WHERE is_occupied = 1"
    ).fetchone()[0]
    earnings = conn.execute("""
        SELECT COALESCE(SUM(fee), 0) FROM parking
        WHERE exit_time IS NOT NULL AND date(exit_time) = date('now', 'localtime')
    """).fetchone()[0]
    conn.close()
    return jsonify({
        "total": total,
        "occupied": occupied,
        "free": total - occupied,
        "earnings_today": earnings,
        "rate_per_hour": RATE_PER_HOUR,
    })


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
