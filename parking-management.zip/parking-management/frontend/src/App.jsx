import { useState, useEffect } from "react";

const API = "http://127.0.0.1:5000/api";

function App() {
  // State: data from the backend
  const [slots, setSlots] = useState([]);
  const [parked, setParked] = useState([]);
  const [history, setHistory] = useState([]);
  const [summary, setSummary] = useState({ free: 0, occupied: 0, earnings_today: 0, rate_per_hour: 0 });

  // State: form input and feedback message
  const [vehicle, setVehicle] = useState("");
  const [message, setMessage] = useState({ text: "", isError: false });

  // Fetch everything from Flask
  const loadData = async () => {
    setSlots(await fetch(`${API}/slots`).then((r) => r.json()));
    setParked(await fetch(`${API}/parked`).then((r) => r.json()));
    setHistory(await fetch(`${API}/history`).then((r) => r.json()));
    setSummary(await fetch(`${API}/summary`).then((r) => r.json()));
  };

  // Runs once when the page loads
  useEffect(() => {
    loadData();
  }, []);

  // POST /api/checkin
  const checkIn = async (e) => {
    e.preventDefault();
    const res = await fetch(`${API}/checkin`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ vehicle_number: vehicle }),
    });
    const data = await res.json();
    if (res.ok) {
      setMessage({ text: data.message, isError: false });
      setVehicle("");
    } else {
      setMessage({ text: data.error, isError: true });
    }
    loadData();
  };

  // PUT /api/checkout/<id>
  const checkOut = async (parkingId) => {
    const res = await fetch(`${API}/checkout/${parkingId}`, { method: "PUT" });
    const data = await res.json();
    if (res.ok) {
      setMessage({
        text: `${data.message}. Parked ${data.hours} hr(s), fee: ₹${data.fee}`,
        isError: false,
      });
    } else {
      setMessage({ text: data.error, isError: true });
    }
    loadData();
  };

  return (
    <div className="page">
      <header>
        <h1>Parking Slot Management</h1>
        <p>Rate: ₹{summary.rate_per_hour} per hour, rounded up to the next hour</p>
      </header>

      {/* Summary cards */}
      <div className="cards">
        <div className="card">
          <span className="number free">{summary.free}</span>
          <span>Free slots</span>
        </div>
        <div className="card">
          <span className="number busy">{summary.occupied}</span>
          <span>Occupied</span>
        </div>
        <div className="card">
          <span className="number">₹{summary.earnings_today}</span>
          <span>Earned today</span>
        </div>
      </div>

      {message.text && (
        <p className={message.isError ? "message error" : "message"}>{message.text}</p>
      )}

      {/* Check-in form */}
      <section>
        <h2>Check in a vehicle</h2>
        <form onSubmit={checkIn} className="row">
          <input
            placeholder="Vehicle number, e.g. TN09AB1234"
            value={vehicle}
            onChange={(e) => setVehicle(e.target.value)}
            required
          />
          <button type="submit">Park vehicle</button>
        </form>
      </section>

      {/* Slot grid: one box per slot */}
      <section>
        <h2>Parking slots</h2>
        <div className="grid">
          {slots.map((s) => (
            <div key={s.id} className={s.is_occupied ? "slot occupied" : "slot free"}>
              <strong>{s.slot_number}</strong>
              <small>{s.is_occupied ? s.vehicle_number : "Free"}</small>
            </div>
          ))}
        </div>
      </section>

      {/* Currently parked */}
      <section>
        <h2>Currently parked</h2>
        {parked.length === 0 ? (
          <p className="empty">No vehicles parked right now.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Vehicle</th>
                <th>Slot</th>
                <th>Entry time</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {parked.map((p) => (
                <tr key={p.id}>
                  <td>{p.vehicle_number}</td>
                  <td>{p.slot_number}</td>
                  <td>{p.entry_time}</td>
                  <td>
                    <button onClick={() => checkOut(p.id)}>Check out</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>

      {/* Recent history */}
      <section>
        <h2>Recent visits</h2>
        {history.length === 0 ? (
          <p className="empty">No completed visits yet.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Vehicle</th>
                <th>Slot</th>
                <th>Entry</th>
                <th>Exit</th>
                <th>Fee</th>
              </tr>
            </thead>
            <tbody>
              {history.map((h) => (
                <tr key={h.id}>
                  <td>{h.vehicle_number}</td>
                  <td>{h.slot_number}</td>
                  <td>{h.entry_time}</td>
                  <td>{h.exit_time}</td>
                  <td>₹{h.fee}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </div>
  );
}

export default App;
